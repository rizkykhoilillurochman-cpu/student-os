// Student OS public AI gateway (Vercel). Provider secrets stay server-side.
const MAX_PROMPT = 50000;
const MAX_SYSTEM_PROMPT = 20000;
const MAX_ATTACHMENT_B64 = 8500000;
const WINDOW_MS = 60000;
const MAX_REQUESTS_PER_WINDOW = 12;
const MODEL_ALLOWLIST = {gemini:new Set(['gemini-3-flash-preview']),openai:new Set(['gpt-5.6-luna']),claude:new Set(['claude-sonnet-5'])};
const hits = new Map();
const json=(status,body)=>new Response(JSON.stringify(body),{status,headers:{'content-type':'application/json; charset=utf-8','cache-control':'no-store','x-content-type-options':'nosniff'}});
const text=(v,max)=>typeof v==='string'?v.slice(0,max):'';
const clientId=req=>((req.headers.get('x-forwarded-for')||'').split(',')[0]||req.headers.get('x-real-ip')||'unknown').trim().slice(0,80);
function allowed(ip){const now=Date.now(),old=hits.get(ip)||[],fresh=old.filter(t=>now-t<WINDOW_MS);if(fresh.length>=MAX_REQUESTS_PER_WINDOW){hits.set(ip,fresh);return false}fresh.push(now);hits.set(ip,fresh);if(hits.size>5000){for(const [k,v] of hits)if(v.every(t=>now-t>=WINDOW_MS))hits.delete(k)}return true}
async function withTimeout(promise,ms=45000){let timer;const timeout=new Promise((_,reject)=>{timer=setTimeout(()=>reject(new Error('UPSTREAM_TIMEOUT')),ms)});try{return await Promise.race([promise,timeout])}finally{clearTimeout(timer)}}
async function readJson(req){const len=Number(req.headers.get('content-length')||0);if(len>12000000)throw Object.assign(new Error('REQUEST_TOO_LARGE'),{status:413});return req.json()}
export default async function handler(req){
  if(req.method==='OPTIONS')return new Response(null,{status:204,headers:{'access-control-allow-origin':'same-origin','access-control-allow-methods':'POST, OPTIONS','access-control-allow-headers':'content-type'}});
  if(req.method!=='POST')return json(405,{error:'Method not allowed'});
  if(!allowed(clientId(req)))return json(429,{error:'Terlalu banyak permintaan. Coba lagi sekitar 1 menit lagi.'});
  try{
    const b=await readJson(req),provider=String(b?.provider||''),model=String(b?.model||''),prompt=text(b?.prompt,MAX_PROMPT),systemPrompt=text(b?.systemPrompt,MAX_SYSTEM_PROMPT),attachment=b?.attachment||null;
    if(!MODEL_ALLOWLIST[provider])return json(400,{error:'Provider tidak didukung'});
    if(!MODEL_ALLOWLIST[provider].has(model))return json(400,{error:'Model tidak diizinkan untuk provider ini'});
    if(!prompt.trim())return json(400,{error:'Prompt wajib diisi'});
    if(prompt.length!==String(b?.prompt||'').length)return json(413,{error:'Prompt terlalu panjang'});
    if(systemPrompt.length!==String(b?.systemPrompt||'').length)return json(413,{error:'Instruksi sistem terlalu panjang'});
    if(attachment){const mime=String(attachment.mime||''),data=String(attachment.data||'');if(data.length>MAX_ATTACHMENT_B64)return json(413,{error:'Lampiran terlalu besar untuk gateway publik'});if(data&&!/^image\/(jpeg|png|webp|gif)$/.test(mime))return json(400,{error:'Lampiran gambar tidak didukung oleh gateway'})}
    let r,j;
    if(provider==='gemini'){
      if(!process.env.GEMINI_API_KEY)return json(503,{error:'Provider Gemini belum dikonfigurasi di server'});
      const parts=[{text:prompt}];if(attachment?.data)parts.push({inlineData:{mimeType:attachment.mime,data:attachment.data}});
      r=await withTimeout(fetch(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent?key=${encodeURIComponent(process.env.GEMINI_API_KEY)}`,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({contents:[{parts}],systemInstruction:{parts:[{text:systemPrompt}]}})}));
      j=await r.json().catch(()=>({}));if(!r.ok)return json(r.status,{error:j?.error?.message||'Gemini request failed'});return json(200,{text:j?.candidates?.[0]?.content?.parts?.map(x=>x.text||'').join('')||'',sources:j?.candidates?.[0]?.groundingMetadata?.groundingAttributions||[]});
    }
    if(provider==='openai'){
      if(!process.env.OPENAI_API_KEY)return json(503,{error:'Provider OpenAI belum dikonfigurasi di server'});
      const content=[{type:'input_text',text:`${systemPrompt}\n\n${prompt}`}];if(attachment?.data)content.push({type:'input_image',image_url:`data:${attachment.mime};base64,${attachment.data}`});
      r=await withTimeout(fetch('https://api.openai.com/v1/responses',{method:'POST',headers:{'content-type':'application/json','authorization':`Bearer ${process.env.OPENAI_API_KEY}`},body:JSON.stringify({model,input:[{role:'user',content}]})}));
      j=await r.json().catch(()=>({}));if(!r.ok)return json(r.status,{error:j?.error?.message||'OpenAI request failed'});return json(200,{text:j?.output_text||j?.output?.flatMap(x=>x.content||[]).map(x=>x.text||'').join('')||''});
    }
    if(provider==='claude'){
      if(!process.env.ANTHROPIC_API_KEY)return json(503,{error:'Provider Claude belum dikonfigurasi di server'});
      const content=[{type:'text',text:`${systemPrompt}\n\n${prompt}`}];if(attachment?.data)content.push({type:'image',source:{type:'base64',media_type:attachment.mime,data:attachment.data}});
      r=await withTimeout(fetch('https://api.anthropic.com/v1/messages',{method:'POST',headers:{'content-type':'application/json','x-api-key':process.env.ANTHROPIC_API_KEY,'anthropic-version':'2023-06-01'},body:JSON.stringify({model,max_tokens:4096,messages:[{role:'user',content}]})}));
      j=await r.json().catch(()=>({}));if(!r.ok)return json(r.status,{error:j?.error?.message||'Claude request failed'});return json(200,{text:(j?.content||[]).map(x=>x.text||'').join('')});
    }
  }catch(e){if(e?.status===413||e?.message==='REQUEST_TOO_LARGE')return json(413,{error:'Request terlalu besar'});if(e?.message==='UPSTREAM_TIMEOUT')return json(504,{error:'Provider AI melewati batas waktu 45 detik'});console.error('AI gateway error',e?.message||e);return json(500,{error:'Terjadi kesalahan pada gateway AI. Coba lagi.'})}
}
